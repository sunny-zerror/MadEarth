import React from 'react'

const Nav = () => {
  return (
    <div className='h-[10vh] z-10 absolute font-medium w-full backdrop-blur-md text-white text-2xl center'>
        <p>MadEarth </p>
    </div>
  )
}

export default Nav